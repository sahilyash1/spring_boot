package com.quiz.boot;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;

import com.quiz.boot.controller.UserController;
import com.quiz.boot.dao.UserDAO;
import com.quiz.boot.model.UserResponse;
import com.quiz.boot.service.UserService;


@AutoConfigureMockMvc
@WebMvcTest
@ContextConfiguration(classes=SpringBootDemoApplication.class)
@ExtendWith(MockitoExtension.class)
class TestUserController {

	
	@AfterEach
	void tearDown() throws Exception {
	}

	private MockMvc mockMvc;
	//@Mock
	@Autowired
	private UserService userService;
	//@InjectMocks
	@Autowired
	private UserController userController;
	


	@BeforeEach
	public void setUp() {
		//MockitoAnnotations.initMocks(this);
		//mockMvc=MockMvcBuilders.standaloneSetup(userController).build();
		
	}
	
	@Test
	public void testGetUser() {
		try {
			List<UserResponse> userResponseList = new ArrayList<UserResponse>();

			UserResponse userResponse = new UserResponse();
			userResponse.setId(2);
			userResponse.setFirstName("john");
			userResponse.setLastName("cena");
			userResponse.setPassword("john");
			userResponse.setEmail("john@gmail.com");
			userResponse.setPhone("963787565");
			userResponse.setAddress("Shriji colony");
			userResponse.setCountry("India");
			userResponse.setDob("1995-06-25");
			userResponse.setStatus("ACTIVE");
			userResponse.setRole("ROLE_ADMIN");

			userResponseList.add(userResponse);

			when(userService.getAllUser()).thenReturn(userResponseList);

			ResponseEntity<List<UserResponse>> responseEntity = userController.getUser();

			List<UserResponse> responseBody = responseEntity.getBody();

			assertTrue(responseBody.size() > 0);
		} catch (Exception e) {

			assertTrue(false);
		}
	}
	
	
	
	 /* @Test
	  void persistUserPositive() {
		  RegistrationModel registrationModel=new RegistrationModel();
		 
		  registrationModel.setId(16);
		  registrationModel.setFirstName("sumi");
		  registrationModel.setLastName("singh");
		  registrationModel.setPassword("sumi");
		  registrationModel.setEmail("sumi@gmail.com");
		  registrationModel.setPhone("7654726289");
		  registrationModel.setAddress("mumbai");
		  registrationModel.setCountry("england");
		  registrationModel.setDob("1997-02-12");
		  registrationModel.setStatus("ACTIVE");
		  
		 
		  
		  when(userService.setUser(registrationModel)).thenReturn(true);
		 ResponseEntity<String> responseEntity = userController.registration(registrationModel);
		   String useresponseResponse = responseEntity.getBody();
		  assertEquals(registrationModel.getId(), );
		 
	


}*/
	
	

}
