package com.quiz.boot;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.quiz.boot.controller.UserController;
import com.quiz.boot.dao.QuestionDAO;
import com.quiz.boot.dao.QuestionDAOImpl;
import com.quiz.boot.dao.UserDAO;
import com.quiz.boot.entities.Answer;
import com.quiz.boot.entities.Question;
import com.quiz.boot.entities.User;
import com.quiz.boot.model.UserResponse;
import com.quiz.boot.service.QuestionService;
import com.quiz.boot.service.UserService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@ContextConfiguration(classes = SpringBootDemoApplication.class)
class TestQuizQuestionDAO {

	@BeforeEach
	void setUp() throws Exception {

	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@MockBean
	private QuestionDAO questionDAO;
	@Autowired
	private QuestionService questionService;

	@Autowired
	private UserService userService;
	@InjectMocks
	private UserController userController;

	@MockBean
	private UserDAO userDAO;

	@Test
	public void getAllUserTest() {

		when(userDAO
				.getAllUsers())
						.thenReturn(Stream
								.of(new User(111, "jeet", "kumar", "amitsharma", "jeet@gmail.com", "963787565",
										"shriji colony", "India", "1998-12-2022", "ACTIVE", "ROLE_USER"))
								.collect(Collectors.toList()));

		assertEquals(1, userService.getAllUser().size());
	}


	@Test
	public void getUserByEmailId() {
		String string = "amits@gmail.com";

		when(userDAO.getUserDetailsByEmailId(string)).thenReturn(new User(1, "amit", "sharma", "amitsharma",
				"amits@gmail.com", "963787565", "shriji colony", "India", "1998-12-2022", "ACTIVE", "ROLE_USER"));
		assertEquals(1, userService.getUserDetailsByEmailId(string).size());

	}

	@Disabled
	@Test
	void getAllQuestions() {
		when(questionDAO.getQuestionList()).thenReturn(Stream.of(new Question(100, "What is Java", "option1", "option2",
				"option3", "option4", "JAVA", "BASIC", (new Answer(100, "answer")))).collect(Collectors.toList()));

		assertEquals(1, questionService.getQuestionsList());
		/*
		 * List<Question> questionList = questionDAO.getQuestionList();
		 * assertTrue(questionList.size() > 0);
		 */
	}
	
	@Disabled
	@Test
	public void testGetUser() {
		try {
			List<UserResponse> userResponseList = new ArrayList<UserResponse>();

			UserResponse userResponse = new UserResponse();
			userResponse.setId(2);
			userResponse.setFirstName("john");
			userResponse.setLastName("cena");
			userResponse.setPassword("john");
			userResponse.setEmail("john@gmail.com");
			userResponse.setPhone("963787565");
			userResponse.setAddress("Shriji colony");
			userResponse.setCountry("India");
			userResponse.setDob("1995-06-25");
			userResponse.setStatus("ACTIVE");
			userResponse.setRole("ROLE_ADMIN");

			userResponseList.add(userResponse);

			when(userService.getAllUser()).thenReturn(userResponseList);

			ResponseEntity<List<UserResponse>> responseEntity = userController.getUser();

			List<UserResponse> responseBody = responseEntity.getBody();

			assertTrue(responseBody.size() > 0);
		} catch (Exception e) {

			assertTrue(false);
		}
	}
	
}
