package com.quiz.boot.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.quiz.boot.entities.Question;
import com.quiz.boot.entities.Topic;
import com.quiz.boot.model.AnswerResponse;
import com.quiz.boot.model.QuestionResponse;


@Service
public interface QuestionService {
	
	public List<Question> getCQuestionBank();

	public List<Question> getQuestionList();
	public List<QuestionResponse> getQuestionsList();
	public List<AnswerResponse> getAnswerList();
	public List<QuestionResponse> getQuestionsByTopicAndLevel(String topic,String level);
	public List<Topic> getTopicList();
}
