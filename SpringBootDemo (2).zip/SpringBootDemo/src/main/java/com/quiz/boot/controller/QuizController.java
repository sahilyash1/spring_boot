package com.quiz.boot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.quiz.boot.entities.Score;
import com.quiz.boot.entities.Topic;
import com.quiz.boot.entities.User;
import com.quiz.boot.exception.AuthenticationException;
import com.quiz.boot.model.AnswerResponse;
import com.quiz.boot.model.LoginResponse;
import com.quiz.boot.model.QuestionResponse;
import com.quiz.boot.model.RegistrationModel;
import com.quiz.boot.model.ScoreModel;
import com.quiz.boot.model.UserModel;
import com.quiz.boot.model.UserResponse;
import com.quiz.boot.service.AuthenticationService;
import com.quiz.boot.service.QuestionService;
import com.quiz.boot.service.UserService;


@RestController
@RequestMapping("quiz")
@CrossOrigin("*")
public class QuizController {
	
	@Autowired
	QuestionService questionService;
	
	
	@GetMapping("question")
	public ResponseEntity<List<QuestionResponse>> getQuestions(){
		List<QuestionResponse> questionList = questionService.getQuestionsList();
				
		ResponseEntity<List<QuestionResponse>> response=null;
		if(questionList!=null) {
			
			response=new ResponseEntity<List<QuestionResponse>>(questionList,HttpStatus.OK);
		}else {
			response=new ResponseEntity<List<QuestionResponse>>(questionList,HttpStatus.BAD_REQUEST);
		}
		return response;
		
	}
	@GetMapping("question/{topic}/{level}")
	public ResponseEntity<List<QuestionResponse>> getQuestionsByTopicAndLevel(@PathVariable("topic")String topic,
			@PathVariable("level")String level){
		List<QuestionResponse> questionList = questionService.getQuestionsByTopicAndLevel(topic,level);
				
		ResponseEntity<List<QuestionResponse>> response=null;
		if(questionList!=null) {
			
			response=new ResponseEntity<List<QuestionResponse>>(questionList,HttpStatus.OK);
		}else {
			response=new ResponseEntity<List<QuestionResponse>>(questionList,HttpStatus.BAD_REQUEST);
		}
		return response;
		
	}
	@GetMapping("answer")
	public ResponseEntity<List<AnswerResponse>> getAnswers(){
		List<AnswerResponse> answerList = questionService.getAnswerList();
		ResponseEntity<List<AnswerResponse>> response=null;
		if(answerList!=null) {
			System.out.println(answerList.toString());
			response=new ResponseEntity<List<AnswerResponse>>(answerList,HttpStatus.OK);
		}else {
			response=new ResponseEntity<List<AnswerResponse>>(answerList,HttpStatus.BAD_REQUEST);
		}
		return response;
		
	}
	
	@GetMapping("getTopic")
	public ResponseEntity<List<Topic>> getTopic(){
		
		List<Topic> list = questionService.getTopicList();
		ResponseEntity<List<Topic>> response=null;
		if(list!=null) {
			response=new ResponseEntity<List<Topic>>(list,HttpStatus.OK);
		}else {
			response=new ResponseEntity<List<Topic>>(list,HttpStatus.BAD_REQUEST);
		}
		return response;
	}
	
}
