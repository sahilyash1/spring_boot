package com.quiz.boot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.quiz.boot.entities.Answer;
import com.quiz.boot.entities.Question;
import com.quiz.boot.entities.Topic;
import com.quiz.boot.model.QuestionResponse;


@Repository
public interface QuestionDAO {
	
	public List<Question> getCQuestionBank();
	public List<Question> getQuestionList();
	public List<Answer> getAnswerList();
	public List<Question> getQuestionsByTopicAndLevel(String topic, String level);
	public List<Topic> getTopicList();
}
