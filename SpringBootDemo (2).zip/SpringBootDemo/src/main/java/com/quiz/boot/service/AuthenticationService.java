package com.quiz.boot.service;

import java.util.List;

import com.quiz.boot.entities.Login;
import com.quiz.boot.exception.AuthenticationException;
import com.quiz.boot.model.LoginResponse;
import com.quiz.boot.model.UserModel;

@FunctionalInterface
public interface AuthenticationService {
	public List<LoginResponse> authenticationService(UserModel userModel) throws AuthenticationException;
}
