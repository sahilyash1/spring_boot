package com.quiz.boot.dao;

import java.util.List;

//import org.springframework.security.core.userdetails.UserDetails;

import com.quiz.boot.entities.Login;
import com.quiz.boot.entities.Score;
import com.quiz.boot.entities.User;
import com.quiz.boot.model.RegistrationModel;
import com.quiz.boot.model.ScoreModel;

public interface UserDAO {
	public void setUserData(User user);
	public List<Login> authenticationUser(Login login);
	public User getUserDetailsByEmailId(String email);
	public boolean setUser(User user);
	public List<User> getAllUsers();
	public List<Login> getLoginDetails();
	public boolean setScore(Score score);
	public List<Score> getScore(String email);
	public Login getLoginByEmail(String email);
	//public UserDetails getUserByEmail(String email);
}
