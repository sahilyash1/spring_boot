package com.quiz.boot.entities;

public class UserStatus {
	private int userStatusId;
	private String status;
	private int topic1;
	private int topic2;
	private int topic3;
	private int topic4;

	
	public int getUserStatusId() {
		return userStatusId;
	}

	public void setUserStatusId(int userStatusId) {
		this.userStatusId = userStatusId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getTopic1() {
		return topic1;
	}

	public void setTopic1(int topic1) {
		this.topic1 = topic1;
	}

	public int getTopic2() {
		return topic2;
	}

	public void setTopic2(int topic2) {
		this.topic2 = topic2;
	}

	public int getTopic3() {
		return topic3;
	}

	public void setTopic3(int topic3) {
		this.topic3 = topic3;
	}

	public int getTopic4() {
		return topic4;
	}

	public void setTopic4(int topic4) {
		this.topic4 = topic4;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + topic1;
		result = prime * result + topic2;
		result = prime * result + topic3;
		result = prime * result + topic4;
		result = prime * result + userStatusId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserStatus other = (UserStatus) obj;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (topic1 != other.topic1)
			return false;
		if (topic2 != other.topic2)
			return false;
		if (topic3 != other.topic3)
			return false;
		if (topic4 != other.topic4)
			return false;
		if (userStatusId != other.userStatusId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "UserStatus [userStatusId=" + userStatusId + ", status=" + status + ", topic1=" + topic1 + ", topic2="
				+ topic2 + ", topic3=" + topic3 + ", topic4=" + topic4 + "]";
	}
 

}
