package com.quiz.boot.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.quiz.boot.dao.AuthenticationUserDAO;
import com.quiz.boot.entities.Login;
import com.quiz.boot.exception.AuthenticationException;
import com.quiz.boot.model.LoginResponse;
import com.quiz.boot.model.UserModel;


@Service
public class AuthenticationServiceImpl implements AuthenticationService{
	private final static Logger logger = Logger.getLogger(AuthenticationServiceImpl.class);
	final String CLASS_NAME = "AuthenticationServiceImpl";

	@Autowired
	private AuthenticationUserDAO authenticationUserDAO;

	public List<LoginResponse> authenticationService(UserModel userModel) throws AuthenticationException {
		logger.debug(CLASS_NAME + ".authenticationService() invoked, userModel : " + userModel.toString());
		AuthenticationService authenticationService = (user)->{
			 List<Login> logins = authenticationUserDAO.authenticationUser(user);
			List<LoginResponse> response = new ArrayList<>();
			 for(Login login:logins) {
				
				LoginResponse responses = new LoginResponse();
				responses.setLoginId(login.getLoginId());
				responses.setEmailId(login.getEmailId());
				responses.setPassword(login.getPassword());
				responses.setUser(login.getUser());
				response.add(responses);
				
			}
			 return response;
		};
		return authenticationService.authenticationService(userModel);
	}

	
}
