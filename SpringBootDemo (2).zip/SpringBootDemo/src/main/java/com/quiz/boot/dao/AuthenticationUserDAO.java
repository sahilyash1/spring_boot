package com.quiz.boot.dao;

import java.util.List;

import com.quiz.boot.entities.Login;
import com.quiz.boot.entities.User;
import com.quiz.boot.model.UserModel;

public interface AuthenticationUserDAO {
	public List<Login> authenticationUser(UserModel usermodel);
}
