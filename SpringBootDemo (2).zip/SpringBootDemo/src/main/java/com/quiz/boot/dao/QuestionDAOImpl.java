package com.quiz.boot.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.function.Function;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.quiz.boot.entities.Answer;
import com.quiz.boot.entities.Login;
import com.quiz.boot.entities.Question;
import com.quiz.boot.entities.Topic;


@Repository
@Transactional
public class QuestionDAOImpl implements QuestionDAO {
	private final static Logger logger = Logger.getLogger(QuestionDAOImpl.class);
	final static String CLASS_NAME = "QuestionDAOImpl";

	private static List<Question> questionList;
	
	@Autowired
	private SessionFactory sessionFactory;
	
	private Session getSession() {
		Session session = sessionFactory.getCurrentSession();
		if(session==null) {
			sessionFactory.openSession();
		}
		return session;
	}
	
	public List<Question> getQuestionList() {
		logger.debug(CLASS_NAME + ".getQuestionList() invoked");	
		return getSession().createCriteria(Question.class).list();
	}

	
	@Override
	public List<Question> getCQuestionBank() {
		logger.debug(CLASS_NAME + ".getCQuestionBank() invoked");	
		return getSession().createCriteria(Question.class).list();
		
	}

	@Override
	public List<Answer> getAnswerList() {
		logger.debug(CLASS_NAME + ".getAnswerList() invoked");	
		return getSession().createCriteria(Answer.class).list();
		
	}

	@Override
	public List<Question> getQuestionsByTopicAndLevel(String topic, String level) {
		logger.debug(CLASS_NAME + ".getQuestionsByTopicAndLevel() invoked");	
		Criteria criteria = getSession().createCriteria(Question.class);
		criteria.add(Restrictions.eq("topic", topic));
		criteria.add(Restrictions.eq("level", level));	
		List<Question> result = criteria.list();
		return result;
	
	}

	@Override
	public List<Topic> getTopicList() {
		logger.debug(CLASS_NAME + ".getTopicList() invoked");	
				return getSession().createCriteria(Topic.class).list();
				
	}

	

	
}
