package com.quiz.boot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.quiz.boot.exception.AuthenticationException;
import com.quiz.boot.model.LoginResponse;
import com.quiz.boot.model.RegistrationModel;
import com.quiz.boot.model.ScoreModel;
import com.quiz.boot.model.UserModel;
import com.quiz.boot.model.UserResponse;
import com.quiz.boot.service.AuthenticationService;
import com.quiz.boot.service.UserService;

@RestController
@RequestMapping("user")
@CrossOrigin(origins = "*")
public class UserController {
	@Autowired
	UserService userService;
	@Autowired
	AuthenticationService authenticationService;
	
	@GetMapping("login/{emailId}/{password}")
	public ResponseEntity<List<LoginResponse>> loginUser(@PathVariable("emailId")String emailId,
			@PathVariable("password")String password){
		UserModel userModel = new UserModel();
		userModel.setUserName(emailId);
		userModel.setPassword(password);
		List<LoginResponse> loginResponse = null;
		try {
			loginResponse = authenticationService.authenticationService(userModel);
		} catch (AuthenticationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ResponseEntity<List<LoginResponse>> response=null;
		if(loginResponse!=null) {
			response=new ResponseEntity<List<LoginResponse>>(loginResponse,HttpStatus.OK);
		}else {
			response=new ResponseEntity<List<LoginResponse>>(loginResponse,HttpStatus.BAD_REQUEST);
		}
		return response;
	}

	
	@GetMapping("getAllUsers")
	//@PreAuthorize(value = "hasRole('USER') or hasRole('ADMIN')")
	public ResponseEntity<List<UserResponse>> getUser(){
		
		List<UserResponse> list = userService.getAllUser();
		ResponseEntity<List<UserResponse>> response=null;
		if(list!=null) {
			response=new ResponseEntity<List<UserResponse>>(list,HttpStatus.OK);
		}else {
			response=new ResponseEntity<List<UserResponse>>(list,HttpStatus.BAD_REQUEST);
		}
		return response;
	}
	
	@GetMapping("getLoginDetails")
	public ResponseEntity<List<LoginResponse>> getLoginDetails(){
		
		List<LoginResponse> list = userService.getLoginDetails();
		ResponseEntity<List<LoginResponse>> response=null;
		if(list!=null) {
			response=new ResponseEntity<List<LoginResponse>>(list,HttpStatus.OK);
		}else {
			response=new ResponseEntity<List<LoginResponse>>(list,HttpStatus.BAD_REQUEST);
		}
		return response;
	}
	
	@PostMapping("registration")
	public ResponseEntity<String> registration(@RequestBody RegistrationModel registration){
		boolean register = userService.setUser(registration);
		ResponseEntity<String> response=null;
		if(register) {
			response=new ResponseEntity<String>("Registration Successfully",HttpStatus.ACCEPTED);
		}else {
			response=new ResponseEntity<String>("Registration Failed",HttpStatus.EXPECTATION_FAILED);
		}
		return response;
		
	}
	@GetMapping("getUser/{emailId}")
	public ResponseEntity<List<UserResponse>> getUserByEmail(@PathVariable("emailId")String emailId){
		List<UserResponse> list = userService.getUserDetailsByEmailId(emailId);
		System.out.println("For Testing");
		ResponseEntity<List<UserResponse>> response=null;
		if(list!=null) {
			response=new ResponseEntity<List<UserResponse>>(list,HttpStatus.OK);
		}else {
			response=new ResponseEntity<List<UserResponse>>(list,HttpStatus.BAD_REQUEST);
		}
		return response;
	}
	
	
	@PostMapping("score")
	public ResponseEntity<String> setScore(@RequestBody ScoreModel scoreModel){
		boolean register = userService.setScore(scoreModel);
		ResponseEntity<String> response=null;
		if(register) {
			response=new ResponseEntity<String>("Score Successfully",HttpStatus.ACCEPTED);
		}else {
			response=new ResponseEntity<String>("Score Failed",HttpStatus.EXPECTATION_FAILED);
		}
		return response;
		
	}
	@GetMapping("getScore/{emailId}")
	public ResponseEntity<List<ScoreModel>> getScore(@PathVariable("emailId")String emailId){
		
		List<ScoreModel> list = userService.getScore(emailId);
		ResponseEntity<List<ScoreModel>> response=null;
		if(list!=null) {
			response=new ResponseEntity<List<ScoreModel>>(list,HttpStatus.ACCEPTED);
		}else {
			response=new ResponseEntity<List<ScoreModel>>(list,HttpStatus.EXPECTATION_FAILED);
		}
		return response;
	}
	
}
