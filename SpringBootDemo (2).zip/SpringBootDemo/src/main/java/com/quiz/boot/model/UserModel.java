package com.quiz.boot.model;

public class UserModel {
	private String userName;
	private String password;
	private static int userRowNumber;

	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public static int getUserRowNumber() {
		return userRowNumber;
	}
	public static void setUserRowNumber(int userRowNumber) {
		UserModel.userRowNumber = userRowNumber;
	}
	@Override
	public String toString() {
		return "UserModel [userName=" + userName + ", password=" + password + "]";
	}
	
}
