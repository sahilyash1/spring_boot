package com.quiz.boot.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.quiz.boot.entities.Login;
import com.quiz.boot.entities.User;
import com.quiz.boot.model.UserModel;



@Service
public class AuthenticationUserDAOImpl implements AuthenticationUserDAO {
	private final static Logger logger = Logger.getLogger(AuthenticationUserDAOImpl.class);
	final String CLASS_NAME = "AuthenticationUserDAOImpl";
	//private List<Login> loginList;
	//private static int userRowNumber = 0;
	
	@Autowired
	private UserDAO userDAO;
	
	

	public List<Login> authenticationUser(UserModel userModel) {
		logger.debug(CLASS_NAME + ".authenticationUser() invoked");
		Login login = new Login();
			
		login.setEmailId(userModel.getUserName());
		login.setPassword(userModel.getPassword());
			
		return userDAO.authenticationUser(login);
		
	}
	
	

}
