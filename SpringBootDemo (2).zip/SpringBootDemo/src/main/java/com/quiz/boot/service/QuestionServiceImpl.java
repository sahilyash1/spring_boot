package com.quiz.boot.service;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quiz.boot.dao.QuestionDAO;
import com.quiz.boot.entities.Answer;
import com.quiz.boot.entities.Question;
import com.quiz.boot.entities.Topic;
import com.quiz.boot.model.AnswerResponse;
import com.quiz.boot.model.QuestionResponse;

@Service
public class QuestionServiceImpl implements QuestionService {
	private final static Logger logger = Logger.getLogger(QuestionServiceImpl.class);
	final String CLASS_NAME = "QuestionServiceImpl";
	
	@Autowired
	private QuestionDAO questionDAO;
	
	public List<Question>  getCQuestionBank() {
		logger.debug(CLASS_NAME + ".getCQuestionBank() invoked");		
		return questionDAO.getCQuestionBank();
	}

	
	
	public List<Question> getQuestionList() {
		logger.debug(CLASS_NAME + ".getQuestionList() invoked");	
		return questionDAO.getQuestionList();
	}
	
	
	public List<QuestionResponse> getQuestionsList() {
		logger.debug(CLASS_NAME + ".getQuestionList() invoked");	
		List<Question> questionList = questionDAO.getCQuestionBank();	
		List<QuestionResponse> response = new ArrayList<QuestionResponse>();
		for(Question question:questionList) {
			QuestionResponse questionResponse = new QuestionResponse();
			questionResponse.setQuestionId(question.getQuestionId());
			questionResponse.setQuestion(question.getQuestion());
			questionResponse.setOption1(question.getOption1());
			questionResponse.setOption2(question.getOption2());
			questionResponse.setOption3(question.getOption3());
			questionResponse.setOption4(question.getOption4());
			questionResponse.setTopic(question.getTopic());
			questionResponse.setLevel(question.getLevel());
			questionResponse.setAnswer(question.getAnswer());
			response.add(questionResponse);
		}
		return response;
	}



	@Override
	public List<AnswerResponse> getAnswerList() {
		logger.debug(CLASS_NAME + ".getAnswerList() invoked");	
		List<Answer> answerList = questionDAO.getAnswerList();
		List<AnswerResponse> response = new ArrayList<AnswerResponse>();
		for(Answer answer:answerList) {
			AnswerResponse answers = new AnswerResponse();
			answers.setAnswerId(answer.getAnswerId());
			answers.setAnswer(answer.getAnswer());
			response.add(answers);
		}
		return response;
	}



	@Override
	public List<QuestionResponse> getQuestionsByTopicAndLevel(String topic, String level) {
		logger.debug(CLASS_NAME + ".getQuestionsByTopicAndLevel() invoked");	
		List<Question> questionList = questionDAO.getQuestionsByTopicAndLevel(topic, level);	
		List<QuestionResponse> response = new ArrayList<QuestionResponse>();
		for(Question question:questionList) {
			QuestionResponse questionResponse = new QuestionResponse();
			questionResponse.setQuestionId(question.getQuestionId());
			questionResponse.setQuestion(question.getQuestion());
			questionResponse.setOption1(question.getOption1());
			questionResponse.setOption2(question.getOption2());
			questionResponse.setOption3(question.getOption3());
			questionResponse.setOption4(question.getOption4());
			questionResponse.setTopic(question.getTopic());
			questionResponse.setLevel(question.getLevel());
			questionResponse.setAnswer(question.getAnswer());
			response.add(questionResponse);
		}
		return response;
	}



	@Override
	public List<Topic> getTopicList() {
		logger.debug(CLASS_NAME + ".getTopicList() invoked");	
		return questionDAO.getTopicList();
	}



	

	
}
