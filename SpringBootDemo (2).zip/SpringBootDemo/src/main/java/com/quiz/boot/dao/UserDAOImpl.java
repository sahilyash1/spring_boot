package com.quiz.boot.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.GrantedAuthority;
//import org.springframework.security.core.authority.SimpleGrantedAuthority;

//import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.quiz.boot.entities.UserStatus;

import com.quiz.boot.entities.Login;
import com.quiz.boot.entities.Question;
import com.quiz.boot.entities.Score;
import com.quiz.boot.entities.User;
import com.quiz.boot.model.RegistrationModel;

@Repository
@Transactional
public class UserDAOImpl implements UserDAO {
	private final static Logger logger = Logger.getLogger(UserDAOImpl.class);
	final String CLASS_NAME = "UserDAOImpl";

	@Autowired
	private SessionFactory sessionFactory;

	private Session getSession() {
		Session session = sessionFactory.getCurrentSession();
		if (session == null) {
			sessionFactory.openSession();
		}
		return session;
	}

	public List<Login> authenticationUser(Login login) {
		logger.debug(CLASS_NAME + ".authenticationUser() invoked");
		
		
		String emailId = login.getEmailId();
		String password = login.getPassword();
		
		Criteria criteria = getSession().createCriteria(Login.class);
		criteria.add(Restrictions.eq("password", password));
		criteria.add(Restrictions.eq("email", emailId));
		
		List<Login> result = criteria.list();
		
		return result;
		
	}

	public User getUserDetails(String userId) {
		logger.debug(CLASS_NAME + ".getUserDetails() invoked, userId - " + userId);
		

		Criteria criteria = getSession().createCriteria(User.class).add(Restrictions.eq("id", userId));
		Object results = criteria.uniqueResult();
		if (results != null) {
			User user = (User) results;
			
			return user;
		}
		return null;
	}


	@Override
	public boolean setUser(User user) {
		logger.debug(CLASS_NAME + ".setRegisterUser() invoked");
		
		 if(getSession().save(user) != null) {
			 System.out.println(user.toString());
			 setLogin(user);
			 return true;
		 }

		return false;
	}
	
	public boolean setLogin(User user) {
		Login login= new Login();
		login.setEmailId(user.getEmail());
		login.setPassword(user.getPassword());
		login.setUser(user);
		login.setRole(user.getRole());
		if(getSession().save(login) != null) {
			return true;
		}
		return false;
		
	}

	

	public void setUserData(User user) {
		logger.debug(CLASS_NAME + ".setUserData() invoked");
		/*
		 * UserDAO userDAO = (userModel) -> { UserRepository.setUserDetails(user); };
		 */
		// userDAO.setUserData(user);
	}

	@Override
	public List<User> getAllUsers() {
		logger.debug(CLASS_NAME + ".getAllUsers() invoked");

		return getSession().createCriteria(User.class).list();

	}

	@Override
	public List<Login> getLoginDetails() {
		// TODO Auto-generated method stub
		return getSession().createCriteria(Login.class).list();
	}

	@Override
	public boolean setScore(Score score) {
		logger.debug(CLASS_NAME + ".setRegisterUser() invoked");
		
		 if(getSession().save(score) != null) {return true;}
		return false;
	}

	@Override
	public User getUserDetailsByEmailId(String email) {
        logger.debug(CLASS_NAME + ".getUserDetailsByEmailId() invoked, email - " + email);
		

		Criteria criteria = getSession().createCriteria(User.class).add(Restrictions.eq("email", email));
		Object results = criteria.uniqueResult();
		if (results != null) {
			User user = (User) results;
			
			return user;
		}
		return null;
	}
	

	@Override
	public List<Score> getScore(String email) {
		logger.debug(CLASS_NAME + ".getScore() invoked");
		return getSession().createCriteria(Score.class).add(Restrictions.eq("email", email)).list();

	}

	@Override
	public Login getLoginByEmail(String email) {
		 logger.debug(CLASS_NAME + ".getLoginByEmail() invoked, email - " + email);
			

			Criteria criteria = getSession().createCriteria(Login.class).add(Restrictions.eq("email", email));
			Object results = criteria.uniqueResult();
			if (results != null) {
				Login Login = (Login) results;
				
				return Login;
			}
			return null;

	}
	
	
	/*public UserDetails getUserByEmail(String email) {
		 logger.debug(CLASS_NAME + ".getLoginByEmail() invoked, email - " + email);
		 UserDetails userDetails=null;

			Criteria criteria = getSession().createCriteria(Login.class).add(Restrictions.eq("email", email));
			Object results = criteria.uniqueResult();
			if (results != null) {
				Login login = (Login) results;
		
				//return Login;
			
			List<GrantedAuthority> authorities=new ArrayList<GrantedAuthority>();
			String userNameDB=null;
			String password=null;
			
				GrantedAuthority authority=new SimpleGrantedAuthority(login.getRole());
				authorities.add(authority);
				userNameDB=email;
				password="{noop}"+login.getPassword();
			
			userDetails=new org.springframework.security.core.userdetails.User(userNameDB,
					password,authorities);
			}
			
			
			return userDetails;

	}*/

}
