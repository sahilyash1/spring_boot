package com.quiz.boot.service;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quiz.boot.dao.UserDAO;
import com.quiz.boot.entities.Login;
import com.quiz.boot.entities.Score;
import com.quiz.boot.entities.User;
import com.quiz.boot.model.LoginResponse;
import com.quiz.boot.model.RegistrationModel;
import com.quiz.boot.model.ScoreModel;
import com.quiz.boot.model.UserResponse;

@Service
public class UserServiceImpl implements UserService {
	private final static Logger logger = Logger.getLogger(UserServiceImpl.class);
	final String CLASS_NAME = "UserServiceImpl";

	@Autowired
	private UserDAO userDAO;

	public void setUserData(User user) {
		logger.debug(CLASS_NAME + ".setUserData() invoked");
		userDAO.setUserData(user);

	}

	@Override
	public boolean setUser(RegistrationModel registartion) {
		logger.debug(CLASS_NAME + ".setRegisterUser() invoked");
		String email = registartion.getEmail();
		if (userDAO.getUserDetailsByEmailId(email) != null) {
			return false;
		} else {
			User user = new User();
			user.setFirstName(registartion.getFirstName());
			user.setLastName(registartion.getLastName());
			user.setEmail(registartion.getEmail());
			user.setPassword(registartion.getPassword());
			user.setPhone(registartion.getPhone());
			user.setDob(registartion.getDob());
			user.setAddress(registartion.getAddress());
			user.setCountry(registartion.getCountry());
			user.setStatus("ACTIVE");
			user.setRole("ROLE_USER");
			return userDAO.setUser(user);
		}
	}

	/*
	 * @Override // NOT IN USE public List<User> getAllUsers() { // TODO
	 * Auto-generated method stub
	 * 
	 * return userDAO.getAllUsers(); }
	 */

	public List<UserResponse> getAllUser() {
		// TODO Auto-generated method stub
		List<User> user = userDAO.getAllUsers();

		List<UserResponse> userList = new ArrayList<UserResponse>();
		for (User list : user) {
			UserResponse us = new UserResponse();
			us.setId(list.getId());
			us.setFirstName(list.getFirstName());
			us.setLastName(list.getLastName());
			us.setEmail(list.getEmail());
			us.setPassword(list.getPassword());
			us.setPhone(list.getPhone());
			us.setDob(list.getDob());
			us.setAddress(list.getAddress());
			us.setCountry(list.getCountry());
			us.setStatus(list.getStatus());
			us.setRole(list.getRole());
			userList.add(us);
		}

		return userList;
	}

	@Override // NOT IN USE
	public List<UserResponse> getUser(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<LoginResponse> getLoginDetails() {
		// TODO Auto-generated method stub
		List<Login> loginList = userDAO.getLoginDetails();

		List<LoginResponse> response = new ArrayList<LoginResponse>();
		for (Login login : loginList) {
			LoginResponse loginResponse = new LoginResponse();
			loginResponse.setLoginId(login.getLoginId());
			loginResponse.setEmailId(login.getEmailId());
			loginResponse.setPassword(login.getPassword());
			loginResponse.setUser(login.getUser());
			response.add(loginResponse);
		}
		return response;
	}

	@Override
	public boolean setScore(ScoreModel scoreModel) {
		logger.debug(CLASS_NAME + ".setScore() invoked");
		Score score = new Score();
		score.setEmail(scoreModel.getEmail());
		score.setName(scoreModel.getName());
		score.setMarks(scoreModel.getMarks());
		score.setTopic(scoreModel.getTopic());
		score.setLevel(scoreModel.getLevel());
		String timeStamp = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
		score.setDate(timeStamp);
		return userDAO.setScore(score);

	}

	@Override
	public List<ScoreModel> getScore(String email) {
		logger.debug(CLASS_NAME + ".getScore() invoked");
		List<Score> scoreList =  userDAO.getScore(email);
		
		List<ScoreModel> response = new ArrayList<ScoreModel>();
		for (Score score : scoreList) {
			ScoreModel scoreModel = new ScoreModel();
			scoreModel.setId(score.getId());
			scoreModel.setEmail(score.getEmail());
			scoreModel.setName(score.getName());
			scoreModel.setDate(score.getDate());
			scoreModel.setLevel(score.getLevel());
			scoreModel.setMarks(score.getMarks());
			scoreModel.setTopic(score.getTopic());
			response.add(scoreModel);
		}
		
		return response;
	}

	@Override
	public List<UserResponse> getUserDetailsByEmailId(String email) {
		User list = userDAO.getUserDetailsByEmailId(email);
		List<UserResponse> userList = new ArrayList<UserResponse>();
		
			UserResponse us = new UserResponse();
			us.setId(list.getId());
			us.setFirstName(list.getFirstName());
			us.setLastName(list.getLastName());
			us.setEmail(list.getEmail());
			us.setPassword(list.getPassword());
			us.setPhone(list.getPhone());
			us.setDob(list.getDob());
			us.setAddress(list.getAddress());
			us.setCountry(list.getCountry());
			us.setStatus(list.getStatus());
			us.setRole(list.getRole());
			userList.add(us);
		

		return userList;
		
	}

}
