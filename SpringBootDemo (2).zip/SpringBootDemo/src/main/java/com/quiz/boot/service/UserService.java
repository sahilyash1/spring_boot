package com.quiz.boot.service;

import java.util.List;

import com.quiz.boot.entities.Login;
import com.quiz.boot.entities.User;
import com.quiz.boot.model.LoginResponse;
import com.quiz.boot.model.RegistrationModel;
import com.quiz.boot.model.ScoreModel;
import com.quiz.boot.model.UserResponse;

public interface UserService {
	public void setUserData(User user);
	
	public boolean setUser(RegistrationModel registration);
	//public List<User> getAllUsers();
	public List<UserResponse> getAllUser();
	public List<UserResponse> getUser(int id);
	public List<LoginResponse>  getLoginDetails();
	public boolean setScore(ScoreModel scoreModel);
	public List<ScoreModel> getScore(String email);
	public List<UserResponse> getUserDetailsByEmailId(String email);
	
}
