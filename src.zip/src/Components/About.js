import React, { Fragment } from 'react'
import { Link } from 'react-router-dom';
import Examen from '../Img/examenlogo.png';
import Image from '../Img/img.webp';
import '../Css/About.css';
import { TiSocialFacebookCircular } from "react-icons/ti";
import {  TiSocialLinkedin } from "react-icons/ti";
import {  TiSocialTwitter } from "react-icons/ti";
import { TiSocialPinterestCircular } from "react-icons/ti";
import $ from 'jquery';

export default class About extends React.Component {
    componentDidMount(){

        $('#myDiv').animate({
            height: '500px',
            width: '500px'
        },
            5000, 'swing');

    }
    

    render() {
       
        return (
            <Fragment>
              
                    <header>
                        <nav class="navbar navbar-light bg-light">

                            <Link to="/"> <img src={Examen} alt="examenlogo" width="90" height="50"></img></Link>
                            <div class="navbar navigation-bar">

                                <Link to="/login"> <button class="btn btn-outline-success my-2 my-sm-0" type="submit">
                                    Login</button></Link>

                                <Link to="/registration">  <button class="btn btn-outline-success my-2 my-sm-0" type="submit">
                                    Registration</button></Link>
                            </div>

                        </nav>
                    </header>
                    <section>
                        <div className="image" id="myDiv">
                            <img src={Image} alt="imagelogo" />
                        </div>
                        <div className="content">
                            <h2>About Us</h2>

                            <p>Online Quiz System Project is really an interesting platform for testing your knowledge.

                                It will provide users an online interface where they solve different quizzes online.

                                The other interface will be controlled by the operator who will responsible to create,

                                design and update the quizzes. The users or students will enter their particulars to login

                                and solve a quiz of their choice. It may contain MCQs or other format as designed by the admin or
                                teacher. </p>
                            <div className="icons">
                                <li>
                                    <TiSocialFacebookCircular />
                                </li>
                                <li>
                                    <TiSocialLinkedin />
                                </li>
                                <li>
                                    <TiSocialTwitter />
                                </li>
                                <li>
                                    <TiSocialPinterestCircular />
                                </li>
                            </div>


                        </div>
                    </section>
                    <br>
                    </br>
               
                <footer>
                    <div className="credit">Made with <span style={{ color: 'tomato' }}>❤</span> by Examen</div>
                    <p className="cp-text"> © Copyright 2021 Examen. All rights reserved.
                    </p>
                </footer>

            </Fragment>
        )
    }
}
