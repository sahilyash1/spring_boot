import React, { Fragment } from 'react'
import { Link } from 'react-router-dom';
import '../Css/Update.css';
import Examen from '../Img/examenlogo.png';
import { Form, Button, Card, Dropdown } from 'react-bootstrap'
import axios from 'axios';
import { Redirect } from 'react-router';
import NavigationBar from './NavigationBar';

export default class Update extends React.Component {

    constructor(props) {
        super(props);
        this.state = {

            Id: localStorage.getItem('id'),
            FirstName: localStorage.getItem('firstName'),
            LastName: localStorage.getItem('lastName'),
            Password: localStorage.getItem('password'),
            Email: localStorage.getItem('email'),
            Phone: localStorage.getItem('phone'),
            DOB: localStorage.getItem('dob'),
            Address: localStorage.getItem('address'),



            errors: {
                Id: "",
                FirstName: "",
                LastName: "",
                Password: "",
                Email: "",
                Phone: "",
                DOB: "",
                Address: "",


            },
            disabled: true,

        }


        this.onChangeFirstName = this.onChangeFirstName.bind(this);
        this.onChangeLastName = this.onChangeLastName.bind(this);
        this.onChangeEmail = this.onChangeEmail.bind(this);
        this.onChangePassword = this.onChangePassword.bind(this);
        this.onChangeAddress = this.onChangeAddress.bind(this);
        this.onChangeDOB = this.onChangeDOB.bind(this);
        this.onChangePhone = this.onChangePhone.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
    }

   

    onChangeFirstName(e) {
        this.setState({
            FirstName: e.target.value
        })

    }
    onChangeLastName(e) {
        this.setState({
            LastName: e.target.value

        })
      
    }
    onChangeEmail(e) {
        this.setState({
            Email: e.target.value
        })
    }
    onChangePassword(e) {
        this.setState({
            Password: e.target.value
        })
    }
    onChangeAddress(e) {
        this.setState({
            Address: e.target.value
        })
    }
    onChangeDOB(e) {
        this.setState({
            DOB: e.target.value
        })
    }
    onChangePhone(e) {
        this.setState({
            Phone: e.target.value
        })
    }



    valIdEmailRegex = RegExp(
        /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i
    )




    onSubmit(e) {
        e.preventDefault();
       
        axios({
            method: 'POST',
            url: 'http://localhost:9017/quizApp/user/update',
            data: {
                id: this.state.Id,
                email: this.state.Email,
                password: this.state.Password,
                firstName: this.state.FirstName,
                lastName: this.state.LastName,
                phone: this.state.Phone,
                dob: this.state.DOB,
                address: this.state.Address

            }
        })
            .then(response => {
                console.log({ response: 'Update Successfull' });

                window.alert("Data Updated Succesfully")
               
                localStorage.setItem('firstName',this.state.FirstName);
                localStorage.setItem('lastName',this.state.LastName);
                localStorage.setItem('password',this.state.Password);
                localStorage.setItem('phone',this.state.Phone);
                localStorage.setItem('address',this.state.Address);
                localStorage.setItem('dob',this.state.DOB);
                window.location = "/dashboard";
            })
            .catch(() => {
                console.log("Update Failed");

            });
    }







    render() {
        const { errors } = this.state;
        return (
            <Fragment>
               <NavigationBar/>


                    <div class="box">

                        <div class="page">
                            <div class="header">

                                <Link to="/Update" Id="signup" class="active">Update</Link>
                            </div>
                            <div Id="errorMsg"></div>


                            <form className="signup" name="signupForm" >
                                <Card.Body className="center">
                                    <Form>

                                        <Form.Group>

                                            <Form.Control type="Email" disabled="true" placeholder="Enter Email" name="Email"
                                                defaultValue={this.state.Email}
                                                Value={this.state.Email} onChange={this.onChangeEmail} />
                                            <p Id="error">{errors.Email.length > 0 &&
                                                <span>{errors.Email}</span>}</p>
                                        </Form.Group>
                                        <Form.Group>

                                            <Form.Control type="text" name="FirstName"
                                                defaultValue={this.state.FirstName}
                                                Value={this.state.FirstName} onChange={this.onChangeFirstName} />
                                            <p Id="error">{errors.FirstName.length > 0 &&
                                                <span>{errors.FirstName}</span>}</p>
                                        </Form.Group>

                                        <Form.Group>
                                            <Form.Control type="text" name="LastName" defaultValue={this.state.LastName}
                                                Value={this.state.LastName} onChange={this.onChangeLastName} />
                                            <p Id="error">{errors.LastName.length > 0 &&
                                                <span>{errors.LastName}</span>}</p>
                                        </Form.Group>

                                        <Form.Group>

                                            <Form.Control type="Password" placeholder="Enter Password" name="Password"
                                                defaultValue={this.state.Password}
                                                Value={this.state.Password} onChange={this.onChangePassword} />
                                            <p Id="error">{errors.Password.length > 0 &&
                                                <span>{errors.Password}</span>}</p>
                                        </Form.Group>


                                        <Form.Group>

                                            <Form.Control type="text" placeholder="Phone Number" name="Phone"
                                                defaultValue={this.state.Phone}
                                                Value={this.state.Phone} onChange={this.onChangePhone} />

                                        </Form.Group>

                                        <Form.Group>

                                            <Form.Control type="text" placeholder="Enter Address" name="Address"
                                                defaultValue={this.state.Address}
                                                Value={this.state.Address} onChange={this.onChangeAddress}></Form.Control>
                                        </Form.Group>
                                        <Form.Group>

                                            <Form.Control type="date" placeholder="Enter DOB" name="DOB"
                                                defaultValue={this.state.DOB}
                                                Value={this.state.DOB} onChange={this.onChangeDOB} />
                                            <p Id="error">{errors.DOB.length > 0 &&
                                                <span>{errors.DOB}</span>}</p>
                                        </Form.Group>



                                        <Button onClick={this.onSubmit}>
                                            Update
                                        </Button>
                                    </Form>
                                </Card.Body>


                            </form>

                        </div>
                    </div>

                    <footer>
                        <p className="cp-text"> © Copyright 2021 Examen. All rights reserved.
                        </p>
                    </footer>
                
            </Fragment>
        )
    }
}
const valIdEmailRegex = RegExp(
    /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i
);
let valIdPhoneRegex = RegExp(
    /[0-9]/
);

const valIdateForm = errors => {
    let valId = true;
    Object.values(errors).forEach(val => val.length > 0 && (valId = false));
    return valId;
};

