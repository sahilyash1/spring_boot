
import React from "react";
import axios from "axios";
import '../Css/Quiz.css';
import { Card } from 'react-bootstrap';
import Timer from "./Timer";
import NavigationBar from "./NavigationBar";


export default class Quiz extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            question: [],
        }
    }


    componentDidMount() {
        const topic = localStorage.getItem('topic');
        const level = localStorage.getItem('level');
        console.log(topic);
        console.log(level);
        axios({
            method: 'GET',
            url: 'http://localhost:9017/quizApp/quiz/question/' + topic+'/'+level,
        })
            .then(response => {
                this.setState({ question: response.data });
            })
            .catch((error) => {
                console.log(topic);
            });
    }

    getAnswer = () => {
        let count = 0;
        let flag = this.state.question.map((e, index) => {
            console.log("Correct ANSWER " + e.answer.answer);
            const option = document.getElementsByName(index);
            let checkedoption = "";
            for (let i = 0; i < 4; i++) {
                if (option[i].checked) {
                    checkedoption = option[i].value;
                }
            }
            if (e.answer.answer === checkedoption) {
                count = count + 1;
            }
        })
        console.log("Correct " + count);
        console.log(flag);


        let email = localStorage.getItem('email');
        let firstName = localStorage.getItem('firstName');
        const topic = localStorage.getItem('topic');
        const level = localStorage.getItem('level');
        axios({
            method: 'POST',
            url: 'http://localhost:9017/quizApp/user/score',
            data:
            {
                email: email,
                name: firstName,
                marks: count,
                topic: topic,
                level: level

            }

        })
            .then(response => {
                localStorage.setItem('count',count);
                window.location = "/score";
            })
            .catch((error) => {

            });
    }


    render() {
        return (
            <React.Fragment>
                <NavigationBar/>
                <Timer/>
                <div class="container">
                    <form class="container-text-inner">
                        <h2>Quiz</h2>
                        <div id="div">
                            {this.state.question.map((e, index) => (
                                <Card>
                                     
                                    <Card.Body>
                                    <h3 class="quiz">Q{index + 1} {e.question}</h3>
                                    <input type="radio" name={index} id="option1" value={e.option1} />
                                    <label class="quiz" for="option1" >{e.option1}
                                    </label><br></br>
                                    <input type="radio" name={index} id="option2" value={e.option2} />
                                    <label class="quiz" for="option2" >{e.option2}
                                    </label><br></br>
                                    <input type="radio" name={index} id="option3" value={e.option3} />
                                    <label class="quiz" for="option3" >{e.option3}
                                    </label><br></br>
                                    <input type="radio" name={index} id="option4" value={e.option4} />
                                    <label class="quiz" for="option4" >{e.option4}
                                    </label><br></br>
                                    </Card.Body>
                                    
                                </Card>
                                
                                
                            ))}

                        </div>
                        <br></br>

                        <button type="button" class="btn btn-outline-primary"
                            onClick={this.getAnswer}>Submit</button>

                    </form>
                    <div id="result"></div>
                </div>

            </React.Fragment>
        )


    }




}
