import React, { Fragment } from 'react'
import { Link } from 'react-router-dom';
import '../Css/Registration.css';
import Examen from '../Img/examenlogo.png';
import { Form, Button, Card, Dropdown } from 'react-bootstrap'
import axios from 'axios';


export default class Registration extends React.Component {

    constructor(props) {
        super(props);
        this.state = {

            formData: {
                firstName: "",
                lastName: "",
                password: "",
                email: "",
                phone: "",
                dob: "",
                address: "",
               

            },
            errors: {
                firstName: "",
                lastName: "",
                password: "",
                email: "",
                phone: "",
                dob: "",
                address: "",
               

            },
            disabled: true,

        }

    }


    handleChange = (event) => {
        event.preventDefault();
        let formData = { ...this.state.formData };
        formData[event.target.name] = event.target.value;
        this.setState({ formData });
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'email':
                errors.email =
                    validEmailRegex.test(value)
                        ? ''
                        : 'Email is not valid!';
                break;
            case 'password':
                errors.password =
                    value.length < 4
                        ? 'Password must be at least 4 characters long!'
                        : '';
                break;
            case 'phone':
                errors.phone =
                    validphoneRegex.test(value) &&
                        value.length != 10
                        ? 'Phone no. is not valid!'
                        : '';
                break;
            default:
                break;
        }


        this.setState({ errors, [name]: value });
        if (validateForm(this.state.errors)) {
            this.state.disabled = false;
            console.info('Valid Form')
        } else {
            this.state.disabled = true;
            console.error('Invalid Form')
        }
    }

    validEmailRegex = RegExp(
        /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i
    )




    sendData = (event) => {

        event.preventDefault();

        console.log(this.state.formData);

        axios({
            method: 'POST',
            url: 'http://localhost:9017/quizApp/user/registration',
            data: {
                dob: this.state.formData.dob,
                password: this.state.formData.password,
                firstName: this.state.formData.firstName,
                lastName: this.state.formData.lastName,
                email: this.state.formData.email,
                phone: this.state.formData.phone,
                address: this.state.formData.address,
                status: this.state.formData.status,

            }
        })
            .then(response => {
                console.log("Successfully Registered");

                window.location = "/login"

            })
            .catch((error) => {
                console.log("Registeration Failed");
                window.alert("user already Exist");

            });
    }
    handleShow = () => { this.setState({ showModal: true }) }
    handleClose = () => {
        this.setState({ showModal: false })
        window.location = "/login"
    }






    render() {
        const { errors } = this.state;
        return (
            <Fragment>
                <body>

                    <header>
                        <nav class="navbar navbar-light bg-light">
                        <Link to="/about"><img src={Examen} alt="examenlogo" width="90" height="50"></img></Link>
                        </nav>
                    </header>

                    <div class="box">

                        <div class="page">
                            <div class="header">
                                <Link to="/login" id="login" >login</Link>
                                <Link to="/registration" id="signup" class="active">Registration</Link>
                            </div>
                            <div id="errorMsg"></div>


                            <form className="signup" name="signupForm" >
                                <Card.Body className="center">
                                    <Form>
                                        <Form.Group>

                                            <Form.Control type="text" placeholder="Enter FirstName" name="firstName" value={this.state.formData.firstname} onChange={this.handleChange} />
                                            <p id="error">{errors.firstName.length > 0 &&
                                                <span>{errors.firstName}</span>}</p> 
                                        </Form.Group>

                                        <Form.Group>
                                            <Form.Control type="text" placeholder="Enter LastName" name="lastName" value={this.state.formData.lastname} onChange={this.handleChange} />
                                            <p id="error">{errors.lastName.length > 0 &&
                                                <span>{errors.lastName}</span>}</p>
                                        </Form.Group>

                                        <Form.Group>

                                            <Form.Control type="password" placeholder="Enter Password" name="password" value={this.state.formData.password} onChange={this.handleChange} />
                                            <p id="error">{errors.password.length > 0 &&
                                                <span>{errors.password}</span>}</p>
                                        </Form.Group>

                                        <Form.Group>

                                            <Form.Control type="email" placeholder="Enter Email" name="email" value={this.state.formData.email} onChange={this.handleChange} />
                                            <p id="error">{errors.email.length > 0 &&
                                                <span>{errors.email}</span>}</p>
                                        </Form.Group>

                                        <Form.Group>

                                            <Form.Control type="number" placeholder="Phone Number" name="phone" value={this.state.formData.phone} onChange={this.handleChange} />
                                            <p id="error">{errors.phone.length > 0 &&
                                                <span>{errors.phone}</span>}</p>
                                        </Form.Group>

                                        <Form.Group>

                                            <Form.Control type="text" placeholder="Enter Address" name="address"
                                                value={this.state.formData.address} onChange={this.handleChange}></Form.Control>
                                        </Form.Group>
                                        <Form.Group>

                                            <Form.Control type="date" placeholder="Enter dob" name="dob" value={this.state.formData.dob} onChange={this.handleChange} />
                                            <p id="error">{errors.dob.length > 0 &&
                                                <span>{errors.dob}</span>}</p>
                                        </Form.Group>



                                        <Button onClick={this.sendData}>
                                            Submit
                                        </Button>
                                    </Form>
                                </Card.Body>


                            </form>

                        </div>
                    </div>

                    <footer>
                        <p className="cp-text"> © Copyright 2021 Examen. All rights reserved.
                        </p>
                    </footer>
                </body>
            </Fragment>
        )
    }
}
const validEmailRegex = RegExp(
    /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i
);
let validphoneRegex = RegExp(
    /[0-9]/
);

const validateForm = errors => {
    let valid = true;
    Object.values(errors).forEach(val => val.length > 0 && (valid = false));
    return valid;
};

