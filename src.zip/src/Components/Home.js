import React, { Fragment } from 'react'
import { Link } from 'react-router-dom';
import '../Css/Welcome.css';
import Examen from '../Img/examenlogo.png';
import Cardcap from '../Img/pexels-pixabay-39284.jpg';
import Card from '../Img/pexels-andy-barbour-6684212.jpg';
export default class Welcome extends React.Component {
    render() {
        return (
            <Fragment>

                <body>
                    <div>
                        <nav class="navbar navbar-light bg-light">
                            
                        <Link to="/about"><img src={Examen} alt="examenlogo" width="90" height="50"></img></Link>

                            <div class="navbar navigation-bar">
                            <Link to="/login"> <button class="btn btn-outline-success my-2 my-sm-0" type="submit">
                                   Login</button></Link>

                                   <Link to="/registration">  <button class="btn btn-outline-success my-2 my-sm-0" type="submit">
                                    Registration</button></Link>
                            </div>
                        </nav>
                    </div>

                    <div className="container">
                        <div className="container-text-inner">
                            <h1 id="header">Welcome to Examen</h1>
                            <br></br>
                            <h4>Online Quiz System</h4>

                            <h5>A quiz is a form of game or mind sport in which players attempt to answer questions correctly about
                                a certain or variety of subjects. Quizzes can be used as a brief assessment in education and similar fields
                                to measure growth in knowledge, abilities, or skills. They can also be televised for entertainment purposes,
                                often in a game show format.</h5>

                            <br></br>

                            <div className="row">
                                <div className="col d-flex justify-content-center c1">

                                    <div className="card stretched-link cs1" style={{ width: '18rem' }}>

                                        <a href="#showall=true">
                                            <img className="card-img-top" src={Card} alt="Cardcap"></img>
                                        </a>
                                        <div class="card-body">
                                            <p class="card-text">Are you still giving an old-fashioned exam ?</p>
                                        </div>

                                    </div>
                                </div>
                                <div className="col d-flex justify-content-center ">

                                    <div className="card stretched-link cd2" style={{ width: '18rem' }}>
                                        <a href="#a">
                                            <img class="card-img-top" src={Cardcap} alt="card"></img>
                                        </a>
                                        <div className="card-body">
                                            <p class="card-text">Let's make a change, give an Online Exam</p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <br></br><br></br><br></br>
                            <Link to="/login"><button class="btn btn-outline-primary my-2 my-sm-0" type="submit">
                                Let's Start</button></Link>

                        </div>
                    </div>
                    <footer>
                        <p className="cp-text"> © Copyright 2022 Examen. All rights reserved.
                        </p>
                    </footer>

                </body>
            </Fragment>
        )
    }
}
