import React, { Component, Fragment } from 'react';
import axios from "axios";
import { Link } from 'react-router-dom';
import '../Css/Home.css';
import { Button } from 'react-bootstrap';
import Examen from '../Img/examenlogo.png';
import Table from 'react-bootstrap/Table';
import NavigationBar from './NavigationBar';
export default class UserProfile extends Component {
    constructor() {
        super();
        this.state = {
            score: []

        }
    }


    componentDidMount() {

        axios({
            method: 'GET',
            url: 'http://localhost:9017/quizApp/user/getScore/' + localStorage.getItem('email'),
        })
            .then(response => {
                this.setState({ score: response.data });
            })
            .catch((error) => {

            });
    }
    render() {
        return (
            <Fragment>
                <header>
                <NavigationBar/>
                </header>
                
                <br></br><br></br>
                <Table striped bordered hover variant="light" responsive="sm">

                    <thead >

                        <tr >
                            <th>UserName</th>
                            <th>Email</th>
                            <th>Marks</th>
                            <th>Topic</th>
                            <th>Quiz-level</th>
                            <th>Date</th>

                        </tr>
                    </thead>
                    <tbody >
                        {this.state.score.map(
                            (e) => (
                                <tr key={e.id}>
                                    <td>{e.name}</td>
                                    <td>{e.email}</td>
                                    <td>{e.marks}</td>
                                    <td>{e.topic}</td>
                                    <td>{e.level}</td>
                                    <td>{e.date}</td>

                                </tr>
                            )
                        )}



                    </tbody>

                </Table>
                <div class="col-md-12 text-center">
                    <Link to="/dashBoard"><button class="btnn" type="submit">
                        Home</button></Link></div>

            </Fragment>
        )
    }
}

