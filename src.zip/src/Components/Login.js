import React, { Fragment } from 'react'
import { Link } from 'react-router-dom';
import Examen from '../Img/examenlogo.png';
import '../Css/Login.css';
import axios from "axios";
import { Form, Button, Card } from 'react-bootstrap'

export default class Login extends React.Component {

    constructor(){
        super();
        this.state={
                Email:'',
                Password:'',
                Login:[]
        }
        this.Password = this.Password.bind(this);  
        this.Email = this.Email.bind(this);  
        this.handleSubmit = this.handleSubmit.bind(this);  
    }
    Email(event) {  
        this.setState({Email:event.target.value})
    }  
    Password(event) {  
        this.setState({Password:event.target.value})  
    }  
   
    handleSubmit=(event)=>{
    event.preventDefault();
    console.log(this.state.Email);
    console.log(this.state.Password);
    axios({
        method:'GET',
        url:'http://localhost:9017/quizApp/user/login/'+this.state.Email+'/'+this.state.Password,
        data:{
            email:this.state.Email,
            password:this.state.Password
        }
        })
        .then(response=>{
            console.log({response:'Login Successfull'});
            localStorage.setItem('email',this.state.Email);
            this.setState({ Login: response.data });
            this.state.Login.map((e)=>{
                localStorage.setItem('id',e.user.id);
                localStorage.setItem('firstName',e.user.firstName);
                localStorage.setItem('lastName',e.user.lastName);
                localStorage.setItem('password',e.user.password);
                localStorage.setItem('phone',e.user.phone);
                localStorage.setItem('address',e.user.address);
                localStorage.setItem('dob',e.user.dob);
                

                console.log(e.user.firstName);
            })
            window.location="/dashboard";
       })
       .catch(()=>{
               console.log("Login Failed");
               window.alert("Invalid Login Credentials !!!");
           });
       }
    
    render() {
        const { errors } = this.state;
        return (

            <Fragment>

                <body>
                    <header>
                        <nav class="navbar navbar-light bg-light">
                        <Link to="/about"><img src={Examen} alt="examenlogo" width="90" height="50"></img></Link>
                        </nav>
                    </header>


                    <div class="box">

                        <div class="page">
                            <div class="header">

                                <Link to="/login" id="login" class="active">login</Link>
                                <Link to="/registration" id="signup">Registration</Link>
                            </div>
                            <div id="errorMsg"></div>

                            <form className="login" name="loginForm" >
                                <input type="text" name="name" id="logName" required placeholder="Username"  value={this.state.Email} onChange={this.Email} />
                                
                                <input type="password" name="password" id="logPassword" required placeholder="Password" value={this.state.Password} onChange={this.Password} />
                               
                                <div id="check">
                                    <input type="checkbox" id="remember" />
                                    <label for="remember">Remember me</label>
                                </div>
                                <br></br>
                                <Button  onClick={this.handleSubmit}>
                                    Submit
                                </Button>
                                <a href="#e">Forgot Password?</a>
                            </form>



                        </div>
                    </div>
                    <footer>
                        <p className="cp-text"> © Copyright 2021 Examen. All rights reserved.
                        </p>
                    </footer>

                </body>

            </Fragment >
        )
    }


    validEmailRegex = RegExp(
        /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i
    );
    validateForm = errors => {
        let valid = true;
        Object.values(errors).forEach(val => val.length > 0 && (valid = false));
        return valid;
    };
    
}
