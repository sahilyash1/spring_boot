import React from 'react'
import { Route, Routes } from 'react-router-dom';
import About from './About';
import Login from './Login';
import Registration from './Registration';
import Welcome from './Welcome';
import Home from './Home';
import Quiz from './Quiz';
import Logout from './Logout';
import NavigationBar from './NavigationBar';
import Score from './Score';
import Dashboard from './DashBoard';
import QuizBox from './QuizBox';
import UserProfile from './UserProfile';
import Update from './Update';

export default class Main extends React.Component {
    render() {
        return (

            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/welcome" element={<Welcome />} />
                <Route path="/navbar" element={<NavigationBar />} />
                <Route path="/login" element={<Login />} />
                <Route path="/registration" element={<Registration />} />
                <Route path="/about" element={<About />} />
                <Route path="/quiz" element={<Quiz />} />
                <Route path="/score" element={<Score />} />
                <Route path="/logout" element={<Logout />} />
                <Route path="/update" element={<Update />} />
                <Route path="/dashboard" element={<Dashboard/>}/>
                <Route path="/quizBox" element={<QuizBox/>}/>
                <Route path="/profile" element={<UserProfile/>}/>
            </Routes>

        )
    }
}

