import React, { Component, Fragment } from 'react'
import Examen from '../Img/examenlogo.png';
import { Link } from 'react-router-dom';
import { FaUserCircle } from "react-icons/fa";
import UserProfile from './UserProfile';
import { Dropdown, MenuItem, DropdownButton } from 'react-bootstrap';

export default class NavigationBar extends Component {
    render() {
        let firstName = localStorage.getItem('firstName');
        return <Fragment>
            <nav class="navbar navbar-light bg-light">
                <img src={Examen} alt="examenlogo" width="90" height="50"></img>
                
                        <Dropdown>
                        
                            <Dropdown.Toggle  variant="dark" >
                            <FaUserCircle/>&nbsp;{firstName}
                                <Dropdown.Menu >
                                < Link to="/update"> <Dropdown.Item href="#/action-2">Account</Dropdown.Item></Link>
                                    < Link to="/profile"> <Dropdown.Item href="#/action-2">Score Card</Dropdown.Item></Link>
                                    <Link to="/logout"><Dropdown.Item href="#/action-3">Logout</Dropdown.Item></Link>
                                    
                                </Dropdown.Menu>
                               
                            </Dropdown.Toggle>
                            
                        </Dropdown>

            </nav>
        
        </Fragment>
    }
}


