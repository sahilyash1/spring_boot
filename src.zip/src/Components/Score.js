import React, { Fragment } from 'react'
import { Link } from 'react-router-dom';
import '../Css/Login.css';
import Examen from '../Img/examenlogo.png';
import NavigationBar from './NavigationBar';
 
 
let email = localStorage.getItem('email');
let firstName = localStorage.getItem('firstName');
let count = localStorage.getItem('count');
export default class Score extends React.Component {
 
    render() {
        return (
            <Fragment>
               
                    <NavigationBar/>
 <div>
                    <div className="container">
                        <div className="container-text-inner">
                            <h1 >Score Card</h1>
                            <br></br>
                                <div >
                                 <h4>Name : {firstName}</h4>      
                                 <h4>Score : {count}</h4>
                                 <h4>Your Complete Quiz Score card is sent to this {email} mail Id.</h4>
                                </div>
                           
                            <br></br>
                            <Link to="/dashboard"> <button class="btnn" type="submit">
                               Ok</button></Link>
                               
 
                        </div>
                    </div>
                    <footer>
                        <p className="cp-text"> © Copyright 2022 Examen. All rights reserved.
                        </p>
                    </footer>
                    </div>
            </Fragment>
        )
    }
}
 
