import React, { Fragment } from "react";
import {
    Container,
    Row,
    Col,
    Nav,
    NavItem,
    NavLink,
    Card,
    Button,
} from "react-bootstrap";
import 'bootstrap/dist/css/bootstrap.min.css';

import { useNavigate } from 'react-router-dom';

const QuizBox = (props) => {
    const { description, topic, level } = props;

    const startQuiz = () => {
        localStorage.setItem('topic', topic);
        localStorage.setItem('level', level);
        window.location = "/quiz";
    }
    return (
        
        <Fragment>

            <Card>
                
                
                
                            <p style={{ fontSize: "14px", }}>
                                {topic}&nbsp;{level}
                            </p>
                            <p style={{fontSize: "10px" }}>
                                {description}
                            </p>
                      <br></br>
                        
                    <Button variant="outline-dark" onClick={() => startQuiz({})}>Start</Button>
                    
                </Card>
            
           
        </Fragment>
       
    );
};

export default QuizBox;
