import React, { useState, useEffect, Fragment } from 'react';
import axios from 'axios';
import '../Css/Home.css';
import {
  Container,
  Row,
  Col,
  Nav,
  NavItem,
  NavLink,
  Card,
} from "react-bootstrap";
import QuizBox from "../Components/QuizBox";
import NavigationBar from './NavigationBar';


function Dashboard() {

  const [quizTopic, setquizTopic] = useState([]);
  useEffect(() => {
    axios({
      method: 'GET',
      url: 'http://localhost:9017/quizApp/quiz/getTopic',
    })
      .then(response => {
        setquizTopic(response.data);
      })
      .catch((error) => {

      });
  }, []);
  return (
    <Fragment>

      <NavigationBar />
     


      <div class="landing-page">
        <div class="landing-text-inner">
          <h1>Available Quizes</h1>

          <Container >

            {quizTopic.map((e, index) => (
              <Row>
                < Col>

                  <QuizBox

                    description={e.description}
                    topic={e.topic}
                    level={e.level}
                  />
                </Col>
              </Row>
            ))}

          </Container>

        </div>
      </div>


    </Fragment>
  );
}

export default Dashboard;




