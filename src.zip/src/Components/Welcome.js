import React, { Component, Fragment } from 'react'
import '../Css/Home.css';
import { Card, Button } from 'react-bootstrap';
import NavigationBar from './NavigationBar';



export default class Home extends Component {
    constructor() {
        super()
        this.startQuiz = this.startQuiz.bind(this);
    }

    render() {
        return (
            <Fragment>

                <NavigationBar />
                <div class="landing-page">
                    <div class="landing-text-inner">
                        <h2>Choose The Topic</h2>
                        <Card>
                            <Card.Body>
                                <h3 style={{ color: 'black' }}>Beginner Level Quiz</h3>
                                <Button variant="outline-dark" onClick={() => this.startQuiz('c/basic')}>C</Button>extra &nbsp;
                                <Button variant="outline-dark" onClick={() => this.startQuiz('c++/basic')}>C++</Button>extra &nbsp;
                                <Button variant="outline-dark" onClick={() => this.startQuiz('java/basic')}>JAVA</Button>extra &nbsp;
                                <Button variant="outline-dark" onClick={() => this.startQuiz('python/basic')}>PYTHON</Button>extra &nbsp;
                            </Card.Body>
                        </Card>
                        <Card>
                            <Card.Body>
                                <h3 style={{ color: 'black' }}> Advance Level Quiz</h3>
                                <Button variant="outline-dark" onClick={() => this.startQuiz('c/advance')}>C</Button>extra &nbsp;
                                <Button variant="outline-dark" onClick={() => this.startQuiz('c++/advance')}>C++</Button>extra &nbsp;
                                <Button variant="outline-dark" onClick={() => this.startQuiz('java/advance')}>JAVA</Button>extra &nbsp;
                                <Button variant="outline-dark" onClick={() => this.startQuiz('python/advance')}>PYTHON</Button>extra &nbsp;
                            </Card.Body>
                        </Card>
                    </div>
                </div>

                <footer>
                    <p className="cp-text"> © Copyright 2022 Examen. All rights reserved.
                    </p>
                </footer>
            </Fragment>
        )
    }

    startQuiz = (e) => {
        localStorage.setItem('topic', e);
        window.location = "/quiz";
    }

}
