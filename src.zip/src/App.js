
import './App.css';


import React from 'react';


import Main from './Components/Main';
import Welcome from './Components/Welcome';
function App() {
  return (
    <React.Fragment>
      
        <Welcome/>
        <Main/>
        
        </React.Fragment>
)
}

export default App;
